
import React, { useState } from 'react';
import { TRADE_IN_DATA } from '../constants';
import { Check, Info, ChevronRight, TabletIcon } from 'lucide-react';

const TradeInCalculator: React.FC = () => {
  const [expandedModel, setExpandedModel] = useState<string | null>(null);

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl">
        <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
          <Info className="text-blue-500" size={24} />
          Como avaliamos seu usado?
        </h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-slate-950 p-6 rounded-2xl border-l-4 border-yellow-500">
            <h3 className="text-white font-bold text-lg mb-4">Grade A+ (Sem Detalhes)</h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li className="flex items-center gap-2"><Check size={14} className="text-yellow-500" /> 100% Original e Impecável.</li>
              <li className="flex items-center gap-2"><Check size={14} className="text-yellow-500" /> Saúde da bateria acima de 85%.</li>
              <li className="flex items-center gap-2"><Check size={14} className="text-yellow-500" /> Sem marcas, riscos ou reparos.</li>
              <li className="flex items-center gap-2"><Check size={14} className="text-yellow-500" /> Face ID e True Tone OK.</li>
            </ul>
          </div>
          <div className="bg-slate-950 p-6 rounded-2xl border-l-4 border-red-600">
            <h3 className="text-white font-bold text-lg mb-4">Grade B+ (Com Detalhes)</h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li className="flex items-center gap-2"><Check size={14} className="text-red-600" /> Saúde da bateria abaixo de 85%.</li>
              <li className="flex items-center gap-2"><Check size={14} className="text-red-600" /> Marcas de uso leves ou riscos.</li>
              <li className="flex items-center gap-2"><Check size={14} className="text-red-600" /> Peças Originais Apple.</li>
              <li className="flex items-center gap-2"><Check size={14} className="text-red-600" /> Funcionamento 100% testado.</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 rounded-3xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="p-6 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
          <h3 className="font-bold text-white text-lg">Valores de Avaliação (Trade-in)</h3>
          <span className="text-[10px] font-black text-blue-400 bg-blue-400/10 px-2.5 py-1 rounded-full uppercase tracking-widest">Atualizado 17/01</span>
        </div>
        <div className="divide-y divide-slate-800">
          {TRADE_IN_DATA.map((item, index) => (
            <div key={index} className="transition-all hover:bg-white/[0.01]">
              <button 
                onClick={() => setExpandedModel(expandedModel === item.model ? null : item.model)}
                className="w-full flex justify-between items-center p-6 text-left"
              >
                <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center text-blue-500">
                      <TabletIcon size={20} />
                    </div>
                    <span className="font-bold text-white text-lg">{item.model}</span>
                </div>
                <ChevronRight size={20} className={`text-slate-600 transition-transform duration-300 ${expandedModel === item.model ? 'rotate-90 text-blue-500' : ''}`} />
              </button>
              
              {expandedModel === item.model && (
                <div className="px-6 pb-6 bg-slate-950 space-y-3 animate-fadeIn">
                  <div className="grid grid-cols-3 gap-4 text-[10px] uppercase text-slate-500 font-bold tracking-widest mb-1 px-4 text-center">
                    <div className="text-left">Capacidade</div>
                    <div className="text-yellow-500">Grade A+</div>
                    <div className="text-red-500">Grade B+</div>
                  </div>
                  {item.capacities.map((cap, cIndex) => (
                    <div key={cIndex} className="grid grid-cols-3 gap-4 text-sm items-center py-4 px-4 bg-slate-900 rounded-2xl border border-slate-800">
                      <div className="text-white font-bold">{cap.size}</div>
                      <div className="text-white font-extrabold text-lg text-center">
                        {cap.gradeA.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                      </div>
                      <div className="text-slate-400 font-bold text-center">
                        {cap.gradeB > 0 ? cap.gradeB.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : '-'}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TradeInCalculator;
