
import React, { useState } from 'react';
import { CATALOG, CATEGORIES } from '../constants';
import { Product } from '../types';
import { Search, ChevronRight, CreditCard, Banknote, ShoppingCart, Star } from 'lucide-react';

interface ProductListProps {
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

const ProductList: React.FC<ProductListProps> = ({ onSelectProduct, onAddToCart }) => {
  const [activeCategory, setActiveCategory] = useState<string>('iphones_novos');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredProducts = CATALOG.filter(p => {
    const matchesCategory = activeCategory === 'all' || p.category === activeCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-8">
      {/* Search and Filter */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-center bg-slate-900 p-4 rounded-2xl border border-slate-800 shadow-lg">
        <div className="flex overflow-x-auto gap-2 w-full md:w-auto hide-scrollbar">
          <button
              onClick={() => setActiveCategory('all')}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap ${
                activeCategory === 'all'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
              }`}
            >
              Todos
          </button>
          {CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap ${
                activeCategory === cat.id
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
        <div className="relative w-full md:w-80">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
          <input
            type="text"
            placeholder="Buscar modelos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 text-white pl-11 pr-4 py-2.5 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 transition-all shadow-inner"
          />
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map(product => (
          <div key={product.id} className="bg-slate-900 rounded-[2.5rem] border border-slate-800 p-6 flex flex-col hover:border-blue-500/50 hover:shadow-2xl transition-all duration-300 group relative overflow-hidden">
            {/* Tag de Destaque */}
            <div className="absolute top-0 right-0 bg-blue-600 text-white text-[8px] font-black px-4 py-1 rounded-bl-xl uppercase tracking-widest shadow-lg">
              21x s/ Juros
            </div>

            <div className="flex-1">
              <div className="flex justify-between items-center mb-2">
                 <span className="text-[9px] uppercase font-black text-blue-400 tracking-widest bg-blue-400/10 px-2 py-0.5 rounded">
                   {CATEGORIES.find(c => c.id === product.category)?.label}
                 </span>
                 {product.name.includes('LACRADO') && (
                   <span className="text-[9px] font-bold text-green-500 flex items-center gap-1">
                     <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                     Estoque OK
                   </span>
                 )}
              </div>
              
              <h3 className="text-lg font-bold text-white mb-6 leading-tight group-hover:text-blue-200 transition-colors">
                {product.name}
              </h3>

              {/* FOCO PRINCIPAL: PARCELA 21X */}
              <div className="mb-6 p-5 bg-blue-600/5 rounded-[1.5rem] border border-blue-600/20 group-hover:bg-blue-600/10 transition-all">
                <div className="flex items-center gap-2 text-blue-400 text-[10px] font-black uppercase tracking-widest mb-1">
                  <CreditCard size={12} className="fill-blue-400/20" /> 21x Sem Juros no Cartão
                </div>
                <div className="flex items-baseline gap-1">
                    <span className="text-sm font-bold text-blue-500">21x</span>
                    <p className="text-4xl font-black text-white tracking-tighter">
                    {(product.price21xTotal / 21).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }).replace('R$', '')}
                    </p>
                </div>
                <p className="text-[10px] text-slate-500 font-bold mt-1">Total: {product.price21xTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>
              </div>

              {/* CONDIÇÃO ESPECIAL: À VISTA */}
              <div className="mb-8 px-2 py-3 bg-green-500/5 rounded-2xl border border-green-500/10 flex justify-between items-center">
                <div>
                    <div className="flex items-center gap-2 text-green-500 text-[9px] font-black uppercase tracking-widest">
                        <Star size={10} className="fill-green-500" /> Preço à Vista
                    </div>
                    <p className="text-xl font-black text-green-500 tracking-tighter">
                    {product.priceCash.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                    </p>
                </div>
                <div className="text-[8px] text-slate-500 text-right font-bold uppercase leading-tight">
                    Exclusivo<br/>Pix/Dinheiro
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-5 gap-2">
              <button
                onClick={() => onSelectProduct(product)}
                className="col-span-4 bg-slate-100 hover:bg-white text-slate-950 font-black py-4 rounded-2xl transition-all shadow-lg flex items-center justify-center gap-2 active:scale-95 text-xs uppercase tracking-widest"
              >
                Simular Agora
                <ChevronRight size={16} />
              </button>
              <button
                onClick={() => onAddToCart(product)}
                title="Adicionar ao Orçamento"
                className="col-span-1 bg-slate-800 hover:bg-slate-700 text-white rounded-2xl flex items-center justify-center transition-all active:scale-90 border border-slate-700"
              >
                <ShoppingCart size={20} />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductList;
