

import React, { useState } from 'react';
import { CartItem, Product, TradeInEntry } from '../types';
import { TRADE_IN_DATA, calculateInstallmentTotal } from '../constants';
import { Trash2, Plus, MessageCircle, Printer, Sparkles, ChevronDown, ShoppingBag, Banknote, Copy, CreditCard, Info, LayoutList, Sigma, List } from 'lucide-react';

/* Removed local TradeInEntry interface as it is now in types.ts */

interface CartProps {
  items: CartItem[];
  onRemove: (cartId: string) => void;
  onClear: () => void;
}

const Cart: React.FC<CartProps> = ({ items, onRemove, onClear }) => {
  const [cashDownPayment, setCashDownPayment] = useState<number>(0);
  const [tradeIns, setTradeIns] = useState<TradeInEntry[]>([]);
  const [budgetMode, setBudgetMode] = useState<'total' | 'individual'>('total');
  const [installments, setInstallments] = useState<number>(21);

  const formatMoney = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const getTradeInValue = (entry: TradeInEntry) => {
    const modelData = TRADE_IN_DATA.find(m => m.model === entry.model);
    const capacityData = modelData?.capacities.find(c => c.size === entry.capacity);
    if (!capacityData) return 0;
    return entry.condition === 'A' ? capacityData.gradeA : capacityData.gradeB;
  };

  const totalTradeInValue = tradeIns.reduce((acc, curr) => acc + getTradeInValue(curr), 0);
  const totalDeductions = totalTradeInValue + cashDownPayment;

  const totals = items.reduce((acc, curr) => {
    acc.cash += curr.product.priceCash;
    acc.p21 += curr.product.price21xTotal;
    return acc;
  }, { cash: 0, p21: 0 });

  const finalCash = Math.max(0, totals.cash - totalDeductions);
  const proportionF21 = totals.cash > 0 ? totals.p21 / totals.cash : 0;
  const finalSimulatedTotal = calculateInstallmentTotal(finalCash, installments, proportionF21);

  const addTradeIn = () => {
    setTradeIns([...tradeIns, { id: Math.random().toString(36).substr(2, 9), model: '', capacity: '', condition: 'A' }]);
  };

  const removeTradeIn = (id: string) => {
    setTradeIns(tradeIns.filter(t => t.id !== id));
  };

  const updateTradeIn = (id: string, field: keyof TradeInEntry, value: string) => {
    setTradeIns(tradeIns.map(t => t.id === id ? { ...t, [field]: value } : t));
  };

  const generateMessage = () => {
    if (items.length === 0) return '';
    let msg = `🦁 *Fitch Tecnologia - Orçamento Personalizado* \n\n`;

    if (budgetMode === 'individual') {
      msg += `📋 *Lista de Preços Individuais:*\n\n`;
      items.forEach((item, idx) => {
        msg += `${idx + 1}️⃣ *${item.product.name}*\n`;
        msg += `• 💵 À Vista (PIX): *${formatMoney(item.product.priceCash)}*\n`;
        msg += `• 💳 12x de ${formatMoney(calculateInstallmentTotal(item.product.priceCash, 12, item.product.price21xTotal/item.product.priceCash) / 12)}\n`;
        msg += `• 💳 21x de ${formatMoney(item.product.price21xTotal / 21)}\n\n`;
      });
      msg += `----------------------------\n`;
    } else {
      msg += `📦 *Itens Selecionados:*\n`;
      items.forEach((item, idx) => {
        msg += `${idx + 1}. *${item.product.name}*\n`;
      });
      msg += `\n`;

      if (tradeIns.length > 0 || cashDownPayment > 0) {
        msg += `📝 *Resumo da Negociação:*\n`;
        tradeIns.forEach(t => {
          if (t.model) msg += `• Recebimento: ${t.model} ${t.capacity}\n`;
        });
        if (cashDownPayment > 0) msg += `• Entrada Dinheiro: *${formatMoney(cashDownPayment)}*\n`;
        msg += `\n`;
      }

      msg += `----------------------------\n`;
      msg += `💳 *FECHAMENTO EM ${installments}X:* \n`;
      msg += `*${installments}x de ${formatMoney(finalSimulatedTotal / installments)}*\n`;
      msg += `_(Total no cartão: ${formatMoney(finalSimulatedTotal)})_\n\n`;

      msg += `💵 *VALOR FINAL À VISTA (PIX):*\n`;
      msg += `*${formatMoney(finalCash)}*\n\n`;
    }

    msg += `Qualidade e confiança é Fitch! 🦁`;
    return msg;
  };

  const handlePrint = () => {
    if (items.length === 0) return;
    const printWindow = window.open('', '_blank', 'width=400,height=800');
    if (!printWindow) return;

    const dateStr = new Date().toLocaleDateString('pt-BR');
    const timeStr = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    let mainContent = '';

    if (budgetMode === 'individual') {
        const itemsHtml = items.map(item => `
          <div style="margin-bottom: 5mm; border-bottom: 1px solid #eee; padding-bottom: 3mm;">
            <div class="bold" style="font-size: 11px; margin-bottom: 2mm;">• ${item.product.name}</div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1mm;">
               <span style="font-size: 10px;">12x Cartão:</span>
               <span class="bold">${formatMoney(calculateInstallmentTotal(item.product.priceCash, 12, item.product.price21xTotal/item.product.priceCash) / 12)}</span>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; background: #f8fafc; padding: 2mm; border-radius: 1mm;">
               <span style="font-size: 10px;">À Vista (PIX):</span>
               <span class="bold" style="font-size: 14px;">${formatMoney(item.product.priceCash)}</span>
            </div>
          </div>
        `).join('');
        mainContent = `
            <div class="bold center" style="font-size: 10px; margin-bottom: 4mm; background: #000; color: #fff; padding: 1mm;">LISTA DE PREÇOS INDIVIDUAIS</div>
            ${itemsHtml}
        `;
    } else {
        const itemsHtml = items.map(item => `<div style="font-size: 11px;">• ${item.product.name}</div>`).join('');

        mainContent = `
            <div class="bold" style="font-size: 10px; margin-bottom: 2mm;">ITENS DO ORÇAMENTO:</div>
            ${itemsHtml}
            <div class="divider"></div>
            ${tradeIns.length > 0 || cashDownPayment > 0 ? `
              <div class="center">
                <div class="bold" style="font-size: 10px;">ABATIMENTOS:</div>
                <div style="font-size: 11px;">
                   ${tradeIns.map(t => t.model ? `<div>${t.model} ${t.capacity}</div>` : '').join('')}
                   ${cashDownPayment > 0 ? `<div>Entrada: ${formatMoney(cashDownPayment)}</div>` : ''}
                </div>
              </div>
              <div class="divider"></div>
            ` : ''}
            <div class="center">
              <div class="bold" style="font-size: 11px;">TOTAL PARCELADO (${installments}X):</div>
              <div style="font-size: 24px; font-weight: 900;">${installments}x ${formatMoney(finalSimulatedTotal / installments)}</div>
              <div class="bold">Total: ${formatMoney(finalSimulatedTotal)}</div>
              <div class="pix-highlight">
                <div class="bold" style="font-size: 10px;">VALOR FINAL À VISTA (PIX):</div>
                <div style="font-size: 19px; font-weight: 900;">${formatMoney(finalCash)}</div>
              </div>
            </div>
        `;
    }

    const content = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Fitch Tecnologia - Orçamento</title>
        <style>
          @page { margin: 0; }
          body { font-family: 'Inter', sans-serif; width: 72mm; margin: 0; padding: 5mm; font-size: 13px; color: #000; line-height: 1.2; }
          .center { text-align: center; }
          .bold { font-weight: 800; }
          .divider { border-top: 2px dashed #000; margin: 4mm 0; }
          .validity { background: #000; color: #fff; padding: 3px; font-size: 10px; margin: 3mm 0; display: block; }
          .pix-highlight { background: #f8fafc; border: 1.5px solid #000; padding: 3mm; margin-top: 1mm; border-radius: 2mm; }
        </style>
      </head>
      <body>
        <div class="center">
          <div class="bold" style="font-size: 16px;">FITCH TECNOLOGIA</div>
          <div style="font-size: 9px;">${dateStr} - ${timeStr}</div>
        </div>
        <div class="divider"></div>
        ${mainContent}
        <div class="validity center bold">VÁLIDO SOMENTE PARA HOJE</div>
        <div class="center" style="font-size: 10px; font-weight: bold; margin-top: 5mm;">🦁 QUALIDADE • CONFIANÇA</div>
        <script>window.onload = function() { window.print(); setTimeout(() => window.close(), 500); };</script>
      </body>
      </html>
    `;
    printWindow.document.write(content);
    printWindow.document.close();
  };

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto py-20 text-center animate-fadeIn">
        <div className="w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center mx-auto mb-6 border border-slate-800 shadow-xl">
          <ShoppingBag className="text-slate-700" size={40} />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2 italic uppercase">Carrinho Vazio</h2>
        <button onClick={() => window.location.reload()} className="bg-blue-600 hover:bg-blue-500 text-white px-10 py-4 rounded-2xl font-black transition-all shadow-lg text-xs uppercase tracking-[0.2em]">Ver Catálogo</button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto grid lg:grid-cols-3 gap-8 animate-fadeIn">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-slate-900 rounded-[2.5rem] border border-slate-800 overflow-hidden shadow-xl">
          <div className="p-6 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <ShoppingBag className="text-blue-500" size={20} />
              Produtos Selecionados ({items.length})
            </h3>
            <button onClick={onClear} className="text-[10px] font-black text-slate-600 hover:text-red-500 transition-colors uppercase tracking-[0.2em]">Limpar</button>
          </div>
          <div className="p-6 space-y-4">
            {items.map((item) => (
              <div key={item.cartId} className="flex items-center justify-between p-5 bg-slate-950 rounded-3xl border border-slate-800 hover:border-blue-600/30 transition-all group">
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest mb-1">{item.product.category}</span>
                  <span className="font-bold text-white group-hover:text-blue-200 transition-colors">{item.product.name}</span>
                  <div className="flex gap-4 mt-2">
                    <span className="text-sm font-black text-blue-400">PIX: {formatMoney(item.product.priceCash)}</span>
                  </div>
                </div>
                <button onClick={() => onRemove(item.cartId)} className="p-3 text-slate-700 hover:text-red-500 hover:bg-red-500/10 rounded-2xl transition-all"><Trash2 size={18} /></button>
              </div>
            ))}
          </div>
        </div>

        {budgetMode === 'total' && (
          <div className="bg-slate-900 p-8 rounded-[2.5rem] border border-slate-800 shadow-lg animate-fadeIn">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-white flex items-center gap-3">
                <span className="bg-blue-600 w-8 h-8 rounded-full flex items-center justify-center text-xs">2</span>
                Trocas e Parcelamento
              </h3>
            </div>
            <div className="space-y-6">
              <div>
                <label className="text-xs font-bold text-slate-600 mb-2 block uppercase tracking-widest">Número de Parcelas</label>
                <div className="relative">
                  <select
                    value={installments}
                    onChange={(e) => setInstallments(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 text-white p-4 rounded-xl appearance-none focus:ring-2 focus:ring-blue-600 font-bold"
                  >
                    {Array.from({ length: 21 }, (_, i) => i + 1).map(n => (
                      <option key={n} value={n}>{n}x no Cartão</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 mb-2 block uppercase tracking-widest">Dinheiro de Entrada</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 font-bold">R$</span>
                  <input type="number" value={cashDownPayment || ''} onChange={(e) => setCashDownPayment(Number(e.target.value))} placeholder="0,00" className="w-full bg-slate-950 border border-slate-800 text-white pl-11 pr-4 py-4 rounded-2xl focus:ring-2 focus:ring-blue-600 font-black text-2xl tracking-tighter" />
                </div>
              </div>
              <button onClick={addTradeIn} className="w-full flex items-center justify-center gap-2 text-[10px] font-black bg-blue-600/10 text-blue-400 py-4 rounded-2xl hover:bg-blue-600/20 transition-all uppercase tracking-widest border border-blue-600/20"><Plus size={14} /> Adicionar Aparelho Usado</button>
              
              <div className="space-y-4">
                {tradeIns.map((t, index) => {
                  const modelData = TRADE_IN_DATA.find(m => m.model === t.model);
                  return (
                    <div key={t.id} className="p-6 bg-slate-950 rounded-3xl border border-slate-800 relative group animate-fadeIn">
                      <button onClick={() => removeTradeIn(t.id)} className="absolute -top-2 -right-2 bg-red-600 text-white p-1.5 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={14} /></button>
                      <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <select value={t.model} onChange={(e) => updateTradeIn(t.id, 'model', e.target.value)} className="w-full bg-slate-900 border border-slate-800 text-white p-3.5 rounded-xl font-bold">
                            <option value="">Aparelho...</option>
                            {TRADE_IN_DATA.map(m => <option key={m.model} value={m.model}>{m.model}</option>)}
                          </select>
                        </div>
                        <div>
                          <select value={t.capacity} onChange={(e) => updateTradeIn(t.id, 'capacity', e.target.value)} className="w-full bg-slate-900 border border-slate-800 text-white p-3.5 rounded-xl font-bold">
                            <option value="">GB...</option>
                            {modelData?.capacities.map(c => <option key={c.size} value={c.size}>{c.size}</option>)}
                          </select>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => updateTradeIn(t.id, 'condition', 'A')} className={`flex-1 py-4 rounded-xl border-2 text-[10px] font-black tracking-widest transition-all ${t.condition === 'A' ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-800 text-slate-600'}`}>A+ (85%)</button>
                        <button onClick={() => updateTradeIn(t.id, 'condition', 'B')} className={`flex-1 py-4 rounded-xl border-2 text-[10px] font-black tracking-widest transition-all ${t.condition === 'B' ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-800 text-slate-600'}`}>B+ (84%)</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="space-y-6">
        <div className="sticky top-32">
          <div className="bg-slate-900 rounded-[3rem] border border-slate-800 shadow-2xl overflow-hidden">
            <div className="bg-slate-950 p-2 flex border-b border-slate-800">
                <button onClick={() => setBudgetMode('total')} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${budgetMode === 'total' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:bg-slate-800'}`}>
                    <Sigma size={16} /> Total Consolidado
                </button>
                <button onClick={() => setBudgetMode('individual')} className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${budgetMode === 'individual' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:bg-slate-800'}`}>
                    <LayoutList size={16} /> Lista Preços
                </button>
            </div>

            <div className="p-8 space-y-6">
               {budgetMode === 'total' ? (
                 <>
                    <div className="bg-blue-600 p-8 rounded-[2rem] shadow-xl relative overflow-hidden group">
                        <p className="text-white/70 text-[10px] font-black uppercase tracking-[0.2em] mb-4 text-center">Parcelamento em {installments}x</p>
                        <div className="flex items-center justify-center gap-2 text-5xl font-black text-white tracking-tighter italic">
                            <span className="text-lg text-white/50 mt-2">{installments}x</span>
                            {(finalSimulatedTotal / installments).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }).replace('R$', '')}
                        </div>
                        <p className="text-[10px] text-white/60 mt-4 font-bold uppercase tracking-widest text-center">Total Cartão: {formatMoney(finalSimulatedTotal)}</p>
                    </div>
                    <div className="bg-slate-950 p-6 rounded-3xl border border-green-500/20 shadow-inner flex justify-between items-center">
                        <div>
                            <p className="text-green-500 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Valor Final à Vista</p>
                            <div className="text-3xl font-black text-white tracking-tighter">{formatMoney(finalCash)}</div>
                        </div>
                        <div className="bg-green-500/10 p-3 rounded-2xl text-green-500"><Banknote size={24} /></div>
                    </div>
                 </>
               ) : (
                 <div className="space-y-4">
                    <div className="bg-slate-950 p-6 rounded-[2rem] border border-slate-800 text-center">
                        <List className="mx-auto text-blue-500 mb-2" size={32} />
                        <h4 className="text-white font-black text-xs uppercase tracking-[0.2em]">Orçamento Individual</h4>
                        <p className="text-slate-500 text-[10px] mt-2">Os itens serão listados separadamente com valores de referência.</p>
                    </div>
                 </div>
               )}

               <div className="grid grid-cols-3 gap-2 pt-2">
                   <button onClick={() => { navigator.clipboard.writeText(generateMessage()); alert('Orçamento Copiado!'); }} className="bg-slate-800 hover:bg-slate-700 text-white py-5 rounded-2xl font-black transition-all shadow-lg flex flex-col items-center justify-center gap-1 text-[10px] uppercase tracking-widest active:scale-95"><Copy size={18} /> Copiar</button>
                   <button onClick={handlePrint} className="bg-white hover:bg-slate-100 text-slate-950 py-5 rounded-2xl font-black transition-all flex flex-col items-center justify-center gap-1 shadow-lg text-[10px] uppercase tracking-widest active:scale-95 group"><Printer size={18} className="group-hover:text-blue-600 transition-colors" /> Imprimir</button>
                   <button onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(generateMessage())}`, '_blank')} className="bg-green-600 hover:bg-green-500 text-white py-5 rounded-2xl font-black transition-all shadow-lg flex flex-col items-center justify-center gap-1 text-[10px] uppercase tracking-widest active:scale-95"><MessageCircle size={18} /> WhatsApp</button>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;