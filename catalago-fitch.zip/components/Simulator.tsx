
import React, { useState, useEffect } from 'react';
import { Product, TradeInEntry } from '../types';
import { CATALOG, TRADE_IN_DATA, STORE_LOGO_URL, calculateInstallmentTotal } from '../constants';
import { Copy, RefreshCw, ChevronDown, MessageCircle, Sparkles, Printer, CreditCard, Banknote, Plus, Trash2, Info } from 'lucide-react';

interface SimulatorProps {
  initialProduct?: Product | null;
}

const Simulator: React.FC<SimulatorProps> = ({ initialProduct }) => {
  const [selectedProductId, setSelectedProductId] = useState<string>(initialProduct?.id || '');
  const [cashDownPayment, setCashDownPayment] = useState<number>(0);
  const [tradeIns, setTradeIns] = useState<TradeInEntry[]>([]);
  const [installments, setInstallments] = useState<number>(21);

  const formatMoney = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const selectedProduct = CATALOG.find(p => p.id === selectedProductId);

  const getTradeInValue = (entry: TradeInEntry) => {
    const modelData = TRADE_IN_DATA.find(m => m.model === entry.model);
    const capacityData = modelData?.capacities.find(c => c.size === entry.capacity);
    if (!capacityData) return 0;
    return entry.condition === 'A' ? capacityData.gradeA : capacityData.gradeB;
  };

  const totalTradeInValue = tradeIns.reduce((acc, curr) => acc + getTradeInValue(curr), 0);
  const totalDeductions = totalTradeInValue + cashDownPayment;

  const getSimulatedValues = () => {
    if (!selectedProduct) return null;
    const cashPrice = selectedProduct.priceCash;
    const balanceCash = Math.max(0, cashPrice - totalDeductions);
    
    const factor21x = selectedProduct.price21xTotal / cashPrice;
    const simulatedTotal = calculateInstallmentTotal(balanceCash, installments, factor21x);

    return {
      balanceCash,
      simulatedTotal,
    };
  };

  const sim = getSimulatedValues();

  useEffect(() => {
    if (initialProduct) setSelectedProductId(initialProduct.id);
  }, [initialProduct]);

  const addTradeIn = () => {
    setTradeIns([...tradeIns, { id: Math.random().toString(36).substr(2, 9), model: '', capacity: '', condition: 'A' }]);
  };

  const removeTradeIn = (id: string) => {
    setTradeIns(tradeIns.filter(t => t.id !== id));
  };

  const updateTradeIn = (id: string, field: keyof TradeInEntry, value: string) => {
    setTradeIns(tradeIns.map(t => t.id === id ? { ...t, [field]: value } : t));
  };

  const generateMessage = () => {
    if (!selectedProduct || !sim) return '';
    let msg = `🦁 *Fitch Tecnologia - Orçamento Personalizado* \n\n`;
    msg += `📱 *Aparelho Selecionado:*\n`;
    msg += `*${selectedProduct.name}*\n\n`;

    if (tradeIns.length > 0 || cashDownPayment > 0) {
        msg += `📝 *Condições de Negociação:* \n`;
        tradeIns.forEach(t => {
          if (t.model) msg += `• Recebimento: ${t.model} ${t.capacity}\n`;
        });
        if (cashDownPayment > 0) msg += `• Entrada em dinheiro: *${formatMoney(cashDownPayment)}*\n`;
        msg += `\n`;
    }
    
    msg += `----------------------------\n`;
    msg += `💳 *PLANO ${installments}X NO CARTÃO:*\n`;
    msg += `*${installments}x de ${formatMoney(sim.simulatedTotal / installments)}*\n`;
    msg += `_(Total parcelado: ${formatMoney(sim.simulatedTotal)})_\n\n`;
    
    msg += `💵 *VALOR FINAL À VISTA (PIX):*\n`;
    msg += `*${formatMoney(sim.balanceCash)}*\n\n`;

    msg += `⚠️ *Nota:* Orçamento com base na tabela oficial. Qualidade e confiança é Fitch! 🦁`;
    return msg;
  };

  const handlePrint = () => {
    if (!selectedProduct || !sim) return;

    const printWindow = window.open('', '_blank', 'width=400,height=600');
    if (!printWindow) return;

    const dateStr = new Date().toLocaleDateString('pt-BR');
    const timeStr = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    const content = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Fitch Tecnologia - Orçamento</title>
        <style>
          @page { margin: 0; }
          body { font-family: 'Inter', sans-serif; width: 72mm; margin: 0; padding: 5mm; font-size: 13px; line-height: 1.3; color: #000; }
          .center { text-align: center; }
          .bold { font-weight: 800; }
          .divider { border-top: 2px dashed #000; margin: 4mm 0; }
          .price-parcel { font-size: 26px; font-weight: 900; margin: 1mm 0; }
          .validity { background: #000; color: #fff; padding: 5px; font-size: 11px; margin: 4mm 0; }
          .pix-highlight { background: #f8fafc; border: 1.5px solid #000; padding: 3mm; margin-top: 4mm; border-radius: 2mm; }
          .note { font-size: 9px; font-style: italic; margin-top: 3mm; color: #333; line-height: 1.2; }
          .trade-list { font-size: 11px; margin-top: 2mm; }
        </style>
      </head>
      <body>
        <div class="center">
          <div class="bold" style="font-size: 18px;">FITCH TECNOLOGIA</div>
          <div style="font-size: 9px;">${dateStr} - ${timeStr}</div>
        </div>
        <div class="divider"></div>
        <div class="bold" style="font-size: 11px;">PRODUTO: ${selectedProduct.name}</div>
        <div class="divider"></div>
        
        <div class="center">
          <div class="bold" style="font-size: 11px;">CONDIÇÃO NO CARTÃO (${installments}X):</div>
          <div class="price-parcel">${installments}x ${formatMoney(sim.simulatedTotal / installments)}</div>
          <div style="font-size: 11px; font-weight: 800; margin-bottom: 2mm;">Total no Cartão: ${formatMoney(sim.simulatedTotal)}</div>
          
          <div class="pix-highlight">
            <div class="bold" style="font-size: 10px; color: #000;">VALOR FINAL À VISTA (PIX):</div>
            <div style="font-size: 19px; font-weight: 900;">${formatMoney(sim.balanceCash)}</div>
          </div>
        </div>

        ${tradeIns.length > 0 || cashDownPayment > 0 ? `
          <div class="divider"></div>
          <div class="bold" style="font-size: 10px; text-align: center;">RESUMO DA TROCA/ENTRADA:</div>
          <div class="trade-list center">
            ${tradeIns.map(t => t.model ? `<div>• Recebimento: ${t.model} ${t.capacity}</div>` : '').join('')}
            ${cashDownPayment > 0 ? `<div class="bold">• Entrada PIX: ${formatMoney(cashDownPayment)}</div>` : ''}
          </div>
        ` : ''}

        <div class="divider"></div>
        <div class="validity center bold">VÁLIDO SOMENTE PARA HOJE</div>
        <div class="center" style="font-size: 10px; font-weight: bold; margin-top: 5mm;">
          🦁 QUALIDADE • CONFIANÇA
        </div>
        <script>window.onload = function() { window.print(); setTimeout(() => window.close(), 500); };</script>
      </body>
      </html>
    `;

    printWindow.document.write(content);
    printWindow.document.close();
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
      <div className="space-y-6">
        <div className="bg-slate-900 p-8 rounded-[2rem] border border-slate-800 shadow-lg">
          <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-3">
            <span className="bg-blue-600 w-8 h-8 rounded-full flex items-center justify-center text-xs">1</span>
            Escolha o Modelo e Parcelas
          </h3>
          <div className="space-y-4">
            <div className="relative">
              <select
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-white p-4 rounded-xl appearance-none focus:ring-2 focus:ring-blue-600 font-medium"
              >
                <option value="">Buscar no catálogo...</option>
                {CATALOG.map(p => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
            </div>

            <div>
              <label className="text-[10px] font-black text-slate-500 mb-2 block uppercase tracking-widest">Opções de Parcelamento</label>
              <div className="relative">
                <select
                  value={installments}
                  onChange={(e) => setInstallments(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 text-white p-4 rounded-xl appearance-none focus:ring-2 focus:ring-blue-600 font-bold"
                >
                  {Array.from({ length: 21 }, (_, i) => i + 1).map(n => (
                    <option key={n} value={n}>{n}x no Cartão</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 p-8 rounded-[2rem] border border-slate-800 shadow-lg">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold text-white flex items-center gap-3">
              <span className="bg-blue-600 w-8 h-8 rounded-full flex items-center justify-center text-xs">2</span>
              Abatimentos
            </h3>
            <button 
              onClick={addTradeIn}
              className="flex items-center gap-2 text-[10px] font-black bg-blue-600/10 text-blue-400 px-4 py-2 rounded-xl hover:bg-blue-600/20 transition-all uppercase tracking-widest border border-blue-600/20"
            >
              <Plus size={14} /> Adicionar Troca
            </button>
          </div>
          
          <div className="space-y-6">
            <div>
              <label className="text-xs font-bold text-slate-500 mb-2 block uppercase tracking-widest">Entrada em Dinheiro (PIX)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 font-bold">R$</span>
                <input 
                  type="number"
                  value={cashDownPayment || ''}
                  onChange={(e) => setCashDownPayment(Number(e.target.value))}
                  placeholder="0,00"
                  className="w-full bg-slate-950 border border-slate-800 text-white pl-11 pr-4 py-4 rounded-xl focus:ring-2 focus:ring-blue-600 font-bold text-xl"
                />
              </div>
            </div>

            {tradeIns.map((t, index) => {
              const modelData = TRADE_IN_DATA.find(m => m.model === t.model);
              return (
                <div key={t.id} className="p-6 bg-slate-950 rounded-2xl border border-slate-800 animate-fadeIn relative group">
                  <button 
                    onClick={() => removeTradeIn(t.id)}
                    className="absolute -top-2 -right-2 bg-red-600 text-white p-1.5 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Trash2 size={14} />
                  </button>
                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <select
                        value={t.model}
                        onChange={(e) => updateTradeIn(t.id, 'model', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 text-white p-3.5 rounded-xl text-sm"
                      >
                        <option value="">Aparelho...</option>
                        {TRADE_IN_DATA.map(m => <option key={m.model} value={m.model}>{m.model}</option>)}
                      </select>
                    </div>
                    <div>
                      <select
                        value={t.capacity}
                        onChange={(e) => updateTradeIn(t.id, 'capacity', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 text-white p-3.5 rounded-xl text-sm"
                      >
                        <option value="">GB...</option>
                        {modelData?.capacities.map(c => <option key={c.size} value={c.size}>{c.size}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => updateTradeIn(t.id, 'condition', 'A')} className={`flex-1 py-3 rounded-xl border-2 text-[10px] font-black transition-all ${t.condition === 'A' ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-800 text-slate-500'}`}>A+ (Impecável)</button>
                    <button onClick={() => updateTradeIn(t.id, 'condition', 'B')} className={`flex-1 py-3 rounded-xl border-2 text-[10px] font-black transition-all ${t.condition === 'B' ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-800 text-slate-500'}`}>B+ (Com Marcas)</button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="space-y-6">
          <div className="sticky top-32">
             <div className="bg-slate-900 rounded-[3rem] border border-slate-800 shadow-2xl overflow-hidden">
                 <div className="bg-blue-600 p-6 flex justify-between items-center shadow-lg">
                     <h2 className="text-xl font-black text-white uppercase tracking-tight italic">Simulação Final</h2>
                     <Sparkles className="text-white opacity-50" size={24} />
                 </div>
                 
                 {!selectedProduct ? (
                     <div className="p-16 text-center text-slate-500">
                         <RefreshCw className="mx-auto mb-4 animate-spin-slow opacity-10" size={56} />
                         <p className="font-bold text-xs uppercase tracking-[0.2em]">Configure os campos ao lado</p>
                     </div>
                 ) : sim && (
                     <div className="p-8 space-y-6">
                         <div className="bg-blue-600 p-8 rounded-[2rem] shadow-xl relative overflow-hidden group">
                             <div className="absolute -right-4 -top-4 opacity-10 group-hover:scale-110 transition-transform">
                                <CreditCard size={120} />
                             </div>
                             <p className="text-white/70 text-[10px] font-black uppercase tracking-[0.2em] mb-4">Parcelamento em {installments}x</p>
                             <div className="flex items-center gap-2 text-6xl font-black text-white tracking-tighter italic">
                                 <span className="text-xl text-white/50 mt-2">{installments}x</span>
                                 {(sim.simulatedTotal / installments).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }).replace('R$', '')}
                             </div>
                             <p className="text-[10px] text-white/60 mt-4 font-bold uppercase tracking-widest">Total no Cartão: {formatMoney(sim.simulatedTotal)}</p>
                         </div>

                         <div className="bg-slate-950 p-6 rounded-3xl border border-green-500/20 shadow-inner flex justify-between items-center">
                             <div>
                                <p className="text-green-500 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Valor Final à Vista</p>
                                <div className="text-3xl font-black text-white tracking-tighter">{formatMoney(sim.balanceCash)}</div>
                             </div>
                             <div className="bg-green-500/10 p-2 rounded-xl text-green-500"><Banknote size={24} /></div>
                         </div>

                         <div className="grid grid-cols-3 gap-3 pt-2">
                             <button onClick={() => { navigator.clipboard.writeText(generateMessage()); alert('Orçamento Copiado!'); }} className="bg-slate-800 hover:bg-slate-700 text-white py-5 rounded-2xl font-black transition-all flex flex-col items-center justify-center gap-1 text-[10px] uppercase tracking-widest active:scale-95">
                                 <Copy size={18} /> Copiar
                             </button>
                             <button onClick={handlePrint} className="bg-white hover:bg-slate-100 text-slate-950 py-5 rounded-2xl font-black transition-all flex flex-col items-center justify-center gap-1 shadow-lg text-[10px] uppercase tracking-widest active:scale-95 group">
                                 <Printer size={18} /> Imprimir
                             </button>
                             <button onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(generateMessage())}`, '_blank')} className="bg-green-600 hover:bg-green-500 text-white py-5 rounded-2xl font-black transition-all shadow-lg flex flex-col items-center justify-center gap-1 text-[10px] uppercase tracking-widest active:scale-95">
                                 <MessageCircle size={18} /> WhatsApp
                             </button>
                         </div>
                     </div>
                 )}
             </div>
          </div>
      </div>
    </div>
  );
};

export default Simulator;
