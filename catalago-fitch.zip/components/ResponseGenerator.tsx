
import React, { useState } from 'react';
import { CATALOG } from '../constants';
import { Product } from '../types';
import { Sparkles, Send, Copy, MessageCircle, Info, Zap, List } from 'lucide-react';

const ResponseGenerator: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [generatedResponse, setGeneratedResponse] = useState('');
  const [detectedProducts, setDetectedProducts] = useState<Product[]>([]);

  const normalize = (text: string) => text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  const handleGenerate = () => {
    if (!inputText.trim()) return;
    const tokens = normalize(inputText).split(/[\s,?!.]+/);
    
    // Encontrar todos os produtos que atingem uma pontuação mínima
    const matches = CATALOG.map(p => {
      let score = 0;
      const pName = normalize(p.name);
      tokens.forEach(token => {
        if (token.length < 2) return;
        if (pName.includes(token)) score += 5;
        if (['pro', 'max', 'plus', 'ultra', 'air', 'mini'].includes(token) && pName.includes(token)) score += 3;
        if (['64', '128', '256', '512', '1tb'].includes(token) && pName.includes(token)) score += 4;
        if (['novo', 'lacrado', 'caixa'].includes(token) && pName.includes('lacrado')) score += 5;
        if (['usado', 'seminovo', 'semi'].includes(token) && pName.includes('seminovo')) score += 5;
      });
      return { product: p, score };
    })
    .filter(m => m.score >= 10) // Filtro rigoroso para evitar falsos positivos
    .sort((a, b) => b.score - a.score);

    // Pegar apenas produtos únicos (evitar duplicatas de mesma linha)
    const uniqueMatches: Product[] = [];
    const seenNames = new Set();
    matches.forEach(m => {
      if (!seenNames.has(m.product.name)) {
        uniqueMatches.push(m.product);
        seenNames.add(m.product.name);
      }
    });

    const products = uniqueMatches.slice(0, 5); // Limite de 5 para não poluir
    setDetectedProducts(products);
    
    const formatMoney = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    
    let response = `🦁 *Fitch Tecnologia - Consulta de Preços*\n\n`;

    if (products.length > 0) {
        response += `Encontrei os modelos que você busca: \n\n`;
        products.forEach((p, idx) => {
            const installmentVal = p.price21xTotal / 21;
            response += `${idx + 1}️⃣ *${p.name}*\n`;
            response += `• 💳 21x de ${formatMoney(installmentVal)} s/ juros\n`;
            response += `• 💵 À Vista: *${formatMoney(p.priceCash)}*\n\n`;
        });
        response += `----------------------------\n`;
        response += `✅ Todos com garantia e procedência!\n`;
        response += `Pegamos seu iPhone usado na troca. Qual desses mais te agrada? 😉`;
    } else {
        response = `🦁 *Olá! Tudo bem?*\nTrabalhamos com toda a linha Apple com condições imperdíveis:\n\n✅ *21x SEM JUROS* no cartão\n✅ *Melhor preço à vista* do mercado\n✅ *Pegamos seu usado* na troca\n\nQual modelo e capacidade você está buscando hoje? Assim te passo o valor atualizado agora!`;
    }
    setGeneratedResponse(response);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      <div className="text-center">
          <h2 className="text-3xl font-extrabold text-white mb-2 flex justify-center items-center gap-3 italic">
            <Zap className="text-yellow-500 fill-yellow-500" />
            Resposta Direta
          </h2>
          <p className="text-slate-400 font-medium">Identifica múltiplos modelos e gera a lista na hora</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-slate-900 p-8 rounded-[2rem] border border-slate-800 shadow-xl flex flex-col">
            <label className="text-[10px] font-black text-slate-500 mb-4 uppercase tracking-[0.2em]">Dúvida do Cliente</label>
            <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Ex: 'Preço do 13 128gb e do 15 lacrado'"
                className="flex-1 bg-slate-950 border border-slate-800 rounded-2xl p-5 text-white focus:ring-2 focus:ring-blue-600 transition-all resize-none mb-6 font-medium text-sm shadow-inner"
                rows={6}
            />
            <button
                onClick={handleGenerate}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-5 rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg active:scale-95"
            >
                <Zap size={20} /> Analisar e Responder
            </button>
        </div>

        <div className="bg-slate-900 p-8 rounded-[2rem] border border-slate-800 shadow-xl flex flex-col min-h-[400px]">
            <label className="text-[10px] font-black text-slate-500 mb-4 uppercase tracking-[0.2em]">Orçamento Automático</label>
            {generatedResponse ? (
                <>
                    <div className="flex-1 bg-slate-950 rounded-2xl p-6 text-slate-100 whitespace-pre-wrap border border-slate-800 overflow-y-auto max-h-[350px] text-sm leading-relaxed font-medium">
                        {generatedResponse}
                    </div>
                    {detectedProducts.length > 0 && (
                        <div className="mt-4 flex flex-wrap gap-2">
                          {detectedProducts.map(p => (
                            <span key={p.id} className="text-[9px] font-bold text-blue-400 bg-blue-500/10 px-2 py-1 rounded-lg border border-blue-500/20 uppercase">
                              {p.name.split(' ')[0]} {p.name.split(' ')[1]}
                            </span>
                          ))}
                        </div>
                    )}
                    <div className="grid grid-cols-2 gap-4 mt-6">
                        <button onClick={() => { navigator.clipboard.writeText(generatedResponse); alert('Copiado!'); }} className="bg-slate-800 hover:bg-slate-700 text-white py-4 rounded-xl font-bold text-xs uppercase tracking-widest transition-all">
                            Copiar
                        </button>
                        <button onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(generatedResponse)}`, '_blank')} className="bg-green-600 hover:bg-green-500 text-white py-4 rounded-xl font-bold text-xs uppercase tracking-widest transition-all">
                            WhatsApp
                        </button>
                    </div>
                </>
            ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-slate-800 border-2 border-dashed border-slate-800 rounded-3xl">
                    <List size={48} className="mb-4 opacity-5" />
                    <p className="font-bold text-[10px] uppercase tracking-[0.3em]">Aguardando termos...</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default ResponseGenerator;
