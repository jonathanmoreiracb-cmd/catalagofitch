
import React, { useState } from 'react';
import { CATALOG } from '../constants';
import { Product } from '../types';
import { Sparkles, Send, Copy, MessageCircle, Info, Zap } from 'lucide-react';

const ResponseGenerator: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [generatedResponse, setGeneratedResponse] = useState('');
  const [detectedProduct, setDetectedProduct] = useState<Product | null>(null);

  const normalize = (text: string) => text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  const calculateScore = (product: Product, tokens: string[]) => {
    let score = 0;
    const pName = normalize(product.name);
    tokens.forEach(token => {
      if (token.length < 2) return;
      if (pName.includes(token)) score += 5;
      if (['pro', 'max', 'plus', 'ultra', 'air', 'mini'].includes(token) && pName.includes(token)) score += 3;
      if (['64', '128', '256', '512', '1tb'].includes(token) && pName.includes(token)) score += 4;
      if (['novo', 'lacrado', 'caixa'].includes(token) && pName.includes('lacrado')) score += 5;
      if (['usado', 'seminovo', 'semi'].includes(token) && pName.includes('seminovo')) score += 5;
    });
    return score;
  };

  const handleGenerate = () => {
    if (!inputText.trim()) return;
    const tokens = normalize(inputText).split(/[\s,?!.]+/);
    let bestMatch: Product | null = null, highestScore = 0;
    CATALOG.forEach(p => { const score = calculateScore(p, tokens); if (score > highestScore) { highestScore = score; bestMatch = p; } });
    const product = highestScore >= 5 ? bestMatch : null;
    setDetectedProduct(product);
    
    let response = "";
    if (product) {
        const formatMoney = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
        const installmentVal = product.price21xTotal / 21;
        
        response = `🦁 *Fitch Tecnologia - Resposta Rápida*\n\n`;
        response += `Temos o *${product.name}* disponível em estoque! ✅\n\n`;
        
        response += `💳 *No Cartão (Sem Juros):*\n`;
        response += `*21x de ${formatMoney(installmentVal)}*\n`;
        response += `_(Total: ${formatMoney(product.price21xTotal)})_\n\n`;
        
        response += `💵 *À Vista (PIX/Dinheiro):*\n`;
        response += `*${formatMoney(product.priceCash)}*\n\n`;
        
        response += `Aceitamos seu iPhone usado na troca! Gostaria de reservar este modelo? 😉`;
    } else {
        response = `🦁 *Olá! Tudo bem?*\nTrabalhamos com toda a linha Apple com condições imperdíveis:\n\n✅ *21x SEM JUROS* no cartão\n✅ *Melhor preço à vista* do mercado\n✅ *Pegamos seu usado* na troca\n\nQual modelo e capacidade você está buscando hoje? Assim te passo o valor atualizado agora!`;
    }
    setGeneratedResponse(response);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      <div className="text-center">
          <h2 className="text-3xl font-extrabold text-white mb-2 flex justify-center items-center gap-3 italic">
            <Zap className="text-yellow-500 fill-yellow-500" />
            Resposta Direta
          </h2>
          <p className="text-slate-400 font-medium">Orçamentos práticos para o cliente em segundos</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-slate-900 p-8 rounded-[2rem] border border-slate-800 shadow-xl flex flex-col">
            <label className="text-[10px] font-black text-slate-500 mb-4 uppercase tracking-[0.2em]">Dúvida do Cliente</label>
            <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Ex: 'Quanto tá o 15 128gb no pix?'"
                className="flex-1 bg-slate-950 border border-slate-800 rounded-2xl p-5 text-white focus:ring-2 focus:ring-blue-600 transition-all resize-none mb-6 font-medium text-sm"
                rows={6}
            />
            <button
                onClick={handleGenerate}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-5 rounded-2xl transition-all flex items-center justify-center gap-2 shadow-lg active:scale-95"
            >
                <Zap size={20} /> Gerar Orçamento Direto
            </button>
        </div>

        <div className="bg-slate-900 p-8 rounded-[2rem] border border-slate-800 shadow-xl flex flex-col min-h-[400px]">
            <label className="text-[10px] font-black text-slate-500 mb-4 uppercase tracking-[0.2em]">Texto para WhatsApp</label>
            {generatedResponse ? (
                <>
                    <div className="flex-1 bg-slate-950 rounded-2xl p-6 text-slate-100 whitespace-pre-wrap border border-slate-800 overflow-y-auto max-h-[350px] text-sm leading-relaxed font-medium">
                        {generatedResponse}
                    </div>
                    {detectedProduct && (
                        <div className="mt-4 text-[10px] font-bold text-blue-400 flex items-center gap-2 bg-blue-500/10 p-3 rounded-xl border border-blue-500/20 uppercase tracking-widest">
                            <Info size={14} /> 
                            <span>Identificado: {detectedProduct.name}</span>
                        </div>
                    )}
                    <div className="grid grid-cols-2 gap-4 mt-6">
                        <button onClick={() => { navigator.clipboard.writeText(generatedResponse); alert('Copiado!'); }} className="bg-slate-800 hover:bg-slate-700 text-white py-4 rounded-xl font-bold text-xs uppercase tracking-widest transition-all">
                            Copiar
                        </button>
                        <button onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(generatedResponse)}`, '_blank')} className="bg-green-600 hover:bg-green-500 text-white py-4 rounded-xl font-bold text-xs uppercase tracking-widest transition-all">
                            WhatsApp
                        </button>
                    </div>
                </>
            ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-slate-800 border-2 border-dashed border-slate-800 rounded-3xl">
                    <Send size={48} className="mb-4 opacity-5" />
                    <p className="font-bold text-[10px] uppercase tracking-[0.3em]">Aguardando pergunta...</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default ResponseGenerator;
