
import React from 'react';
import { ShoppingBag, Calculator, DollarSign, MessageSquareText, ShoppingCart } from 'lucide-react';
import { STORE_LOGO_URL } from '../constants';

interface HeaderProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  cartCount: number;
}

const Header: React.FC<HeaderProps> = ({ currentTab, onTabChange, cartCount }) => {
  return (
    <header className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-800 shadow-xl">
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 cursor-pointer group" onClick={() => onTabChange('catalog')}>
            <img 
              src={STORE_LOGO_URL} 
              alt="Fitch Tecnologia" 
              className="w-12 h-12 rounded-full object-contain bg-slate-800 border border-slate-700 shadow-lg group-hover:scale-105 transition-transform"
            />
            <div>
              <h1 className="text-xl font-bold text-white tracking-tight">FITCH TECNOLOGIA</h1>
              <p className="text-[10px] text-blue-400 uppercase font-black tracking-widest leading-none">Apple Experts</p>
            </div>
          </div>
          
          <nav className="flex items-center gap-1 bg-slate-950/50 p-1 rounded-2xl border border-slate-800">
            {[
              { id: 'catalog', label: 'Catálogo', icon: <ShoppingBag size={18} /> },
              { id: 'cart', label: 'Carrinho', icon: (
                <div className="relative">
                  <ShoppingCart size={18} />
                  {cartCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-red-600 text-white text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center border border-slate-900">
                      {cartCount}
                    </span>
                  )}
                </div>
              )},
              { id: 'tradein', label: 'Troca', icon: <DollarSign size={18} /> },
              { id: 'simulator', label: 'Simulador', icon: <Calculator size={18} /> },
              { id: 'generator', label: 'Respostas', icon: <MessageSquareText size={18} /> }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 ${
                  currentTab === tab.id 
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {tab.icon}
                <span className="hidden sm:inline">{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
