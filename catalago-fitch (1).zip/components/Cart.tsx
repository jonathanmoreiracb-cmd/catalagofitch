
import React, { useState, useEffect } from 'react';
import { CartItem, Product } from '../types';
import { TRADE_IN_DATA } from '../constants';
import { Trash2, Plus, MessageCircle, Printer, Sparkles, ChevronDown, ShoppingBag, Banknote, Copy, CreditCard, Info } from 'lucide-react';

interface TradeInEntry {
  id: string;
  model: string;
  capacity: string;
  condition: 'A' | 'B';
}

interface CartProps {
  items: CartItem[];
  onRemove: (cartId: string) => void;
  onClear: () => void;
}

const Cart: React.FC<CartProps> = ({ items, onRemove, onClear }) => {
  const [cashDownPayment, setCashDownPayment] = useState<number>(0);
  const [tradeIns, setTradeIns] = useState<TradeInEntry[]>([]);

  const formatMoney = (val: number) => val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  const getTradeInValue = (entry: TradeInEntry) => {
    const modelData = TRADE_IN_DATA.find(m => m.model === entry.model);
    const capacityData = modelData?.capacities.find(c => c.size === entry.capacity);
    if (!capacityData) return 0;
    return entry.condition === 'A' ? capacityData.gradeA : capacityData.gradeB;
  };

  const totalTradeInValue = tradeIns.reduce((acc, curr) => acc + getTradeInValue(curr), 0);
  const totalDeductions = totalTradeInValue + cashDownPayment;

  const totals = items.reduce((acc, curr) => {
    acc.cash += curr.product.priceCash;
    acc.p21 += curr.product.price21xTotal;
    return acc;
  }, { cash: 0, p21: 0 });

  const finalCash = Math.max(0, totals.cash - totalDeductions);
  
  // Proporção do plano 21x baseado no total à vista vs total 21x
  const proportionF21 = totals.cash > 0 ? totals.p21 / totals.cash : 0;
  const finalP21 = finalCash * proportionF21;

  const addTradeIn = () => {
    setTradeIns([...tradeIns, { id: Math.random().toString(36).substr(2, 9), model: '', capacity: '', condition: 'A' }]);
  };

  const removeTradeIn = (id: string) => {
    setTradeIns(tradeIns.filter(t => t.id !== id));
  };

  const updateTradeIn = (id: string, field: keyof TradeInEntry, value: string) => {
    setTradeIns(tradeIns.map(t => t.id === id ? { ...t, [field]: value } : t));
  };

  const generateMessage = () => {
    if (items.length === 0) return '';
    let msg = `🦁 *Fitch Tecnologia - Orçamento Combo* \n\n`;
    msg += `📦 *Pacote de Itens Selecionados:*\n`;
    items.forEach((item, idx) => {
      msg += `${idx + 1}. *${item.product.name}*\n`;
      msg += `   ↳ 💳 21x de: *${formatMoney(item.product.price21xTotal / 21)}*\n`;
    });
    msg += `\n`;

    if (tradeIns.length > 0 || cashDownPayment > 0) {
      msg += `✅ *Itens de Entrada/Troca:*\n`;
      tradeIns.forEach(t => {
        if (t.model) msg += `• ${t.model} ${t.capacity}\n`;
      });
      if (cashDownPayment > 0) msg += `• Entrada facilitada em dinheiro\n`;
      msg += `\n`;
    }

    msg += `----------------------------\n`;
    msg += `💳 *FECHAMENTO COMBO (21X SEM JUROS):*\n`;
    msg += `*21x de ${formatMoney(finalP21 / 21)}*\n`;
    msg += `_(Total no cartão: ${formatMoney(finalP21)})_\n\n`;

    msg += `💵 *OPORTUNIDADE À VISTA (PIX):*\n`;
    msg += `*${formatMoney(finalCash)}*\n\n`;

    msg += `⚠️ *Nota:* Os preços informados acima já contemplam o crédito aplicado dos itens de entrada. Vamos fechar seu combo agora? 😉`;
    return msg;
  };

  const handlePrint = () => {
    if (items.length === 0) return;
    const printWindow = window.open('', '_blank', 'width=400,height=800');
    if (!printWindow) return;

    const dateStr = new Date().toLocaleDateString('pt-BR');
    const timeStr = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    const itemsHtml = items.map(item => `
      <div style="margin-bottom: 5mm; border-bottom: 1px solid #ddd; padding-bottom: 2mm;">
        <div class="bold" style="font-size: 11px; margin-bottom: 1.5mm;">• ${item.product.name}</div>
        <div style="display: flex; justify-content: space-between; align-items: baseline;">
          <span style="font-size: 14px;" class="bold">21x ${formatMoney(item.product.price21xTotal / 21)}</span>
        </div>
        <div style="font-size: 9px; color: #444; margin-top: 0.5mm;">Preço base individual parcelado: ${formatMoney(item.product.price21xTotal)}</div>
      </div>
    `).join('');

    const content = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Fitch Tecnologia - Orçamento Impresso</title>
        <style>
          @page { margin: 0; }
          body { font-family: 'Inter', sans-serif; width: 72mm; margin: 0; padding: 5mm; font-size: 13px; color: #000; line-height: 1.2; }
          .center { text-align: center; }
          .bold { font-weight: 800; }
          .divider { border-top: 2px dashed #000; margin: 4mm 0; }
          .price-parcel-total { font-size: 26px; font-weight: 900; margin: 1mm 0; }
          .validity { background: #000; color: #fff; padding: 3px; font-size: 10px; margin: 3mm 0; display: block; }
          .pix-highlight { background: #f8fafc; border: 1.5px solid #000; padding: 3mm; margin-top: 4mm; border-radius: 2mm; }
          .note { font-size: 9px; font-style: italic; margin-top: 3mm; line-height: 1.2; color: #333; }
          .trade-list { font-size: 11px; margin-top: 2mm; }
        </style>
      </head>
      <body>
        <div class="center">
          <div class="bold" style="font-size: 16px;">FITCH TECNOLOGIA</div>
          <div class="bold italic" style="font-size: 9px;">APPLE EXPERTS</div>
          <div style="font-size: 9px;">${dateStr} - ${timeStr}</div>
        </div>
        <div class="divider"></div>
        <div class="bold" style="font-size: 10px; margin-bottom: 3mm; text-decoration: underline;">ITENS DO COMBO:</div>
        ${itemsHtml}
        
        <div class="divider"></div>
        ${tradeIns.length > 0 || cashDownPayment > 0 ? `
          <div class="center">
            <div class="bold" style="font-size: 10px; margin-bottom: 1mm;">ITENS DE ENTRADA CONSIDERADOS:</div>
            <div class="trade-list">
               ${tradeIns.map(t => t.model ? `<div>• ${t.model} ${t.capacity}</div>` : '').join('')}
               ${cashDownPayment > 0 ? `<div>• Entrada facilitada em dinheiro</div>` : ''}
            </div>
          </div>
          <div class="note center">Os valores finais já consideram o crédito aplicado referente aos itens entregues na negociação.</div>
          <div class="divider"></div>
        ` : ''}

        <div class="center">
          <div class="bold" style="font-size: 11px; color: #000;">FECHAMENTO COMBO (CARTÃO):</div>
          <div class="price-parcel-total">21x ${formatMoney(finalP21 / 21)}</div>
          <div class="bold" style="font-size: 12px; margin-bottom: 2mm;">Valor Total: ${formatMoney(finalP21)}</div>
          
          <div class="pix-highlight">
            <div class="bold" style="font-size: 10px; color: #000;">OPORTUNIDADE À VISTA (PIX):</div>
            <div style="font-size: 19px; font-weight: 900;">${formatMoney(finalCash)}</div>
          </div>
        </div>

        <div class="validity center bold">VÁLIDO SOMENTE PARA ${dateStr}</div>
        <div class="center" style="font-size: 10px; font-weight: bold; margin-top: 5mm;">🦁 QUALIDADE • CONFIANÇA</div>
        <script>window.onload = function() { window.print(); setTimeout(() => window.close(), 500); };</script>
      </body>
      </html>
    `;
    printWindow.document.write(content);
    printWindow.document.close();
  };

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto py-20 text-center animate-fadeIn">
        <div className="w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center mx-auto mb-6 border border-slate-800 shadow-xl">
          <ShoppingBag className="text-slate-700" size={40} />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2 text-balance italic uppercase tracking-tighter">Seu Carrinho está vazio</h2>
        <p className="text-slate-500 max-w-xs mx-auto mb-8 font-medium">Adicione produtos do catálogo para gerar um orçamento combo.</p>
        <button 
          onClick={() => window.location.reload()} 
          className="bg-blue-600 hover:bg-blue-500 text-white px-10 py-4 rounded-2xl font-black transition-all shadow-lg text-xs uppercase tracking-[0.2em]"
        >
          Ir para o Catálogo
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto grid lg:grid-cols-3 gap-8 animate-fadeIn">
      {/* List Section */}
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-slate-900 rounded-[2.5rem] border border-slate-800 overflow-hidden shadow-xl">
          <div className="p-6 bg-slate-950 border-b border-slate-800 flex justify-between items-center">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <ShoppingBag className="text-blue-500" size={20} />
              Produtos ({items.length})
            </h3>
            <button onClick={onClear} className="text-[10px] font-black text-slate-600 hover:text-red-500 transition-colors uppercase tracking-[0.2em]">
              Limpar Tudo
            </button>
          </div>
          <div className="p-6 space-y-4">
            {items.map((item) => (
              <div key={item.cartId} className="flex items-center justify-between p-5 bg-slate-950 rounded-3xl border border-slate-800 hover:border-blue-600/30 transition-all group">
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-blue-500 uppercase tracking-widest mb-1">
                    {item.product.category}
                  </span>
                  <span className="font-bold text-white group-hover:text-blue-200 transition-colors">
                    {item.product.name}
                  </span>
                  <div className="flex gap-4 mt-2">
                    <span className="text-sm font-black text-blue-400">
                      21x {formatMoney(item.product.price21xTotal / 21)}
                    </span>
                    <span className="text-xs font-bold text-slate-500 mt-0.5">
                      PIX: {formatMoney(item.product.priceCash)}
                    </span>
                  </div>
                </div>
                <button 
                  onClick={() => onRemove(item.cartId)}
                  className="p-3 text-slate-700 hover:text-red-500 hover:bg-red-500/10 rounded-2xl transition-all"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Entry Section */}
        <div className="bg-slate-900 p-8 rounded-[2.5rem] border border-slate-800 shadow-lg">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold text-white flex items-center gap-3">
              <span className="bg-blue-600 w-8 h-8 rounded-full flex items-center justify-center text-xs">2</span>
              Entrada e Trocas
            </h3>
            <button 
              onClick={addTradeIn}
              className="flex items-center gap-2 text-[10px] font-black bg-blue-600/10 text-blue-400 px-4 py-2 rounded-xl hover:bg-blue-600/20 transition-all uppercase tracking-widest border border-blue-600/20"
            >
              <Plus size={14} /> Nova Troca
            </button>
          </div>
          <div className="space-y-6">
            <div>
              <label className="text-xs font-bold text-slate-600 mb-2 block uppercase tracking-widest">Dinheiro de Entrada</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 font-bold">R$</span>
                <input 
                  type="number"
                  value={cashDownPayment || ''}
                  onChange={(e) => setCashDownPayment(Number(e.target.value))}
                  placeholder="0,00"
                  className="w-full bg-slate-950 border border-slate-800 text-white pl-11 pr-4 py-4 rounded-2xl focus:ring-2 focus:ring-blue-600 font-black text-2xl tracking-tighter shadow-inner"
                />
              </div>
            </div>

            {tradeIns.length > 0 && (
              <div className="space-y-4 pt-4 border-t border-slate-800">
                {tradeIns.map((t, index) => {
                  const modelData = TRADE_IN_DATA.find(m => m.model === t.model);
                  return (
                    <div key={t.id} className="p-6 bg-slate-950 rounded-3xl border border-slate-800 animate-fadeIn relative group">
                      <button 
                        onClick={() => removeTradeIn(t.id)}
                        className="absolute -top-2 -right-2 bg-red-600 text-white p-1.5 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 size={14} />
                      </button>
                      <div className="grid md:grid-cols-2 gap-4 mb-4">
                        <div>
                          <label className="text-[10px] font-black text-slate-600 mb-2 block uppercase">Troca {index + 1}</label>
                          <select
                            value={t.model}
                            onChange={(e) => updateTradeIn(t.id, 'model', e.target.value)}
                            className="w-full bg-slate-900 border border-slate-800 text-white p-3.5 rounded-xl font-bold"
                          >
                            <option value="">Selecionar...</option>
                            {TRADE_IN_DATA.map(m => (
                                <option key={m.model} value={m.model}>{m.model}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                            <label className="text-[10px] font-black text-slate-600 mb-2 block uppercase">GB</label>
                            <select
                                value={t.capacity}
                                onChange={(e) => updateTradeIn(t.id, 'capacity', e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 text-white p-3.5 rounded-xl font-bold"
                            >
                                <option value="">...</option>
                                {modelData?.capacities.map(c => (
                                <option key={c.size} value={c.size}>{c.size}</option>
                                ))}
                            </select>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => updateTradeIn(t.id, 'condition', 'A')} className={`flex-1 py-4 rounded-xl border-2 text-[10px] font-black tracking-widest transition-all ${t.condition === 'A' ? 'border-blue-600 bg-blue-600 text-white shadow-lg' : 'border-slate-800 text-slate-600'}`}>GRADE A+</button>
                        <button onClick={() => updateTradeIn(t.id, 'condition', 'B')} className={`flex-1 py-4 rounded-xl border-2 text-[10px] font-black tracking-widest transition-all ${t.condition === 'B' ? 'border-blue-600 bg-blue-600 text-white shadow-lg' : 'border-slate-800 text-slate-600'}`}>GRADE B+</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Totals Section */}
      <div className="space-y-6">
        <div className="sticky top-32">
          <div className="bg-slate-900 rounded-[3rem] border border-slate-800 shadow-2xl overflow-hidden">
            <div className="bg-blue-600 p-6 flex justify-between items-center shadow-lg">
              <h2 className="text-xl font-black text-white uppercase tracking-tight italic">Resumo Final</h2>
              <CreditCard className="text-white opacity-40" size={24} />
            </div>

            <div className="p-8 space-y-6">
               <div className="bg-blue-600 p-8 rounded-[2rem] shadow-xl relative overflow-hidden group">
                  <p className="text-white/70 text-[10px] font-black uppercase tracking-[0.2em] mb-4">Plano Master 21x Sem Juros</p>
                  <div className="flex items-center gap-2 text-5xl font-black text-white tracking-tighter italic">
                      <span className="text-lg text-white/50 mt-2">21x</span>
                      {(finalP21 / 21).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }).replace('R$', '')}
                  </div>
                  <p className="text-[10px] text-white/60 mt-4 font-bold uppercase tracking-widest">Total Cartão: {formatMoney(finalP21)}</p>
               </div>

               <div className="bg-slate-950 p-6 rounded-3xl border border-green-500/20 shadow-inner flex justify-between items-center">
                  <div>
                    <p className="text-green-500 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Especial à Vista</p>
                    <div className="text-3xl font-black text-white tracking-tighter">
                        {formatMoney(finalCash)}
                    </div>
                  </div>
                  <div className="bg-green-500/10 p-3 rounded-2xl text-green-500">
                    <Banknote size={24} />
                  </div>
               </div>

               {totalDeductions > 0 && (
                  <div className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800 flex items-start gap-3">
                    <Info size={16} className="text-blue-500 mt-1 shrink-0" />
                    <div className="text-[10px] text-slate-400 leading-tight">
                        <p className="text-white font-bold mb-1 uppercase tracking-widest text-[9px]">Atenção:</p>
                        Os preços finais informados acima já consideram os abatimentos dos itens de entrada listados.
                    </div>
                  </div>
               )}

               <div className="grid grid-cols-3 gap-2 pt-2">
                   <button 
                     onClick={() => { navigator.clipboard.writeText(generateMessage()); alert('Orçamento Combo Copiado!'); }}
                     className="bg-slate-800 hover:bg-slate-700 text-white py-5 rounded-2xl font-black transition-all shadow-lg flex flex-col items-center justify-center gap-1 text-[10px] uppercase tracking-widest active:scale-95"
                   >
                       <Copy size={18} /> Copiar
                   </button>
                   <button 
                     onClick={handlePrint}
                     className="bg-white hover:bg-slate-100 text-slate-950 py-5 rounded-2xl font-black transition-all flex flex-col items-center justify-center gap-1 shadow-lg text-[10px] uppercase tracking-widest active:scale-95 group"
                   >
                       <Printer size={18} className="group-hover:text-blue-600 transition-colors" /> Imprimir
                   </button>
                   <button 
                     onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(generateMessage())}`, '_blank')}
                     className="bg-green-600 hover:bg-green-500 text-white py-5 rounded-2xl font-black transition-all shadow-lg flex flex-col items-center justify-center gap-1 text-[10px] uppercase tracking-widest active:scale-95"
                   >
                       <MessageCircle size={18} /> WhatsApp
                   </button>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
